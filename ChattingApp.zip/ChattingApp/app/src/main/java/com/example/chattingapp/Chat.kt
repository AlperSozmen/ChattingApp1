package com.example.chattingapp

data class Chat (val user : String, val text : String)